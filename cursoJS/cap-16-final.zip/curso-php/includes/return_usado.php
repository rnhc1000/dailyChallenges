<?php
$variavelRetornada = 'Sou um retorno';
return $variavelRetornada;