<div class="titulo">Desafio</div>

<ul>
    <li>1 + 1 = <?= 1 + 1 ?></li>
    <li>4 + 4 = <?php echo 4 + 4; ?></li>
    <li>8 + 8 = <?= "1" ?><?php echo 3 + 3; ?></li>
</ul>