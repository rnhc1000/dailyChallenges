<div class="titulo">Comentários PHP</div>

<?php
echo "Estou no PHP";
// echo "Comentário";
# echo "Comentário";
# echo // "Comentário";
// echo # "Comentário";
# ?>

<p>Depois do primeiro bloco!</p>
<!-- 
    <p>Comentário HTML 1</p>
    <p>Comentário HTML 2</p>
    <p>Comentário HTML 3</p>
-->

<?php
/*
    Linha 1 do comentário
    Linha 2 do comentário
    Linha 3 do comentário
*/
?>

<p>Depois do segundo bloco!</p>